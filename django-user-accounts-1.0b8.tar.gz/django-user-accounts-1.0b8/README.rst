==============================================
django-user-accounts: user accounts for Django
==============================================

Provides user accounts to a Django project.

Requirements
============

* Django 1.4
* django-appconf (included in ``install_requires``)
* pytz (included in ``install_requires``)

Documentation
=============

See http://django-user-accounts.readthedocs.org/
