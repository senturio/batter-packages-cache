.. bpython documentation master file, created by
   sphinx-quickstart on Mon Jun  8 11:58:16 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

bpython documentation
=====================
Welcome to the bpython documentation files. This is where you
can find all about using and customizing the bpython interpreter.

If you want to find out more about the bpython interpreter you can visit our
website: http://bpython-interpreter.org

Contents:

.. toctree::
   :maxdepth: 2

   authors
   configuration
   themes
   releases
   community
   django
   windows
   changelog
   sourcecode
   bpaste
   tips
   bpdb
