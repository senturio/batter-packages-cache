.. _bpaste:

bpaste
======
bpaste (http://bpaste.net) is the pastebin which we run for bpython. bpython is
configured by default to paste to this pastebin.

Removal
-------
If you want a paste removed from the pastebin you can email Simon at
simon@ikanobori.jp and he will remove the paste for you, be sure to mention the
paste URL.
