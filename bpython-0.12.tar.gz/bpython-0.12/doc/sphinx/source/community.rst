.. _community:

Community
=========
Do you need help with using bpython? Do you want to thank the contributors
personally? Or maybe you want to help out, contribute some code or resources
or want to help in making bpython known to other persons? 

These are the places where you can find us.

IRC
---
You can find us in #bpython on the Freenode network (irc.freenode.net). Don't
worry when you get no response (this does not usually happen) but we are all
from Europe and when you get to the channel during our nighttime you might have
to wait a while for a response.

Mailinglist
-----------
We have a mailinglist at `google groups <http://groups.google.com/group/bpython>`_.
You can post questions there and releases are announced on the mailing
list.

Website
-------
Our main website is http://bpython-interpreter.org/, our documentation can be
found at http://docs.bpython-interpreter.org/ and our pastebin can be found at
http://bpaste.net/.
