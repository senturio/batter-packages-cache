try:
    from .runner import DiscoverRunner  # noqa
except ImportError:
    pass

__version__ = '0.2.2'
